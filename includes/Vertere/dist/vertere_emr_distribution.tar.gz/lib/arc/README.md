ARC2
====

ARC2 is a PHP 5.3 library for working with RDF.
It also provides a MySQL-based triplestore with SPARQL support.