<?php
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'moriarty.inc.php';
require_once MORIARTY_DIR. 'sparqlservicebase.class.php';

/**
 * Represents a store's sparql service
 * @see http://n2.talis.com/wiki/Store_Sparql_Service
 */
class SparqlService extends SparqlServiceBase {

}
?>