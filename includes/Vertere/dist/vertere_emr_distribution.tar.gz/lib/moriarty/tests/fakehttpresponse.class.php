<?php
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'constants.inc.php';
require_once MORIARTY_DIR . 'httprequest.class.php';

class FakeHttpResponse extends HttpResponse {

}
?>
