<?php
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'constants.inc.php';
require_once MORIARTY_DIR . 'storegroup.class.php';
require_once MORIARTY_DIR . 'credentials.class.php';

class StoreGroupTest extends PHPUnit_Framework_TestCase {

}
?>
