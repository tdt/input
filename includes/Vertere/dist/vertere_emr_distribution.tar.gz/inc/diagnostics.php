<?php

function abort($message) {
	die("\nAborted:\n${message}\n\n");
}